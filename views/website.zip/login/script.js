var card = document.getElementById("card");
function openregister() {
  card.style.transform = "rotateY(-180deg)";
}
function openlogin() {
  card.style.transform = "rotateY(0deg)";
}
